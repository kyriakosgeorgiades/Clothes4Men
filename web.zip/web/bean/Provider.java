/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */

/**
 *
 * @author kakos
 */
package bean;  
  
public interface Provider {  
String username="root";
String password="root";
String connUrl="jdbc:derby://localhost:1527/Store";  
  
}  
